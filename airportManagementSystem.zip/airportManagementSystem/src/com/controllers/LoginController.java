package com.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import com.loginaccess.AdminHandler;
import com.pojo.AdminModel;
import com.pojo.AdminRegistration;

@Controller
public class LoginController {
	AdminHandler admin = new AdminHandler();
	@RequestMapping("/")
	public String display(){
		return "index";
	}
	@RequestMapping("adminView")
	public String displayView(@ModelAttribute("admin") AdminModel adminModel){
		//ModelAndView mv = new ModelAndView();
		System.out.println("heyyyy  "+adminModel.getUname()+"   "+adminModel.getPass());
		if(admin.checkUser(adminModel.getUname(),adminModel.getPass())){
			return "view";
		}
		return "index";
	}
	
	@RequestMapping("adminReg.html")
	public String viewRegistrationPage(){
		return "adminRegistration";
	}
	
	@RequestMapping("checkAdminDetails")
	public String adminRegistration(@ModelAttribute("adminReg") AdminRegistration adminReg){
		//ModelAndView mv = new ModelAndView();
		System.out.println("heyyyy  "+adminReg.getFirstName());
		if(admin.adminRegistrationDetails(adminReg)){
			return "index";
		}
		return "adminRegistration";
	}
//	@RequestMapping("addDetails")
//	public String enterDetails(){
//		//System.out.println(planeDetails.getOwnerContactNumber());
//		//ModelAndView mv = new ModelAndView();
//		//Model
//		return "viewPlaneDetails";
//	}
//	
//	@RequestMapping("addPlanes")
//	public String addPlaneDetails(@ModelAttribute("planeDetails") PlaneDetails planeDetails){
//		System.out.println(planeDetails.getOwnerContactNumber());
//		//ModelAndView mv = new ModelAndView();
//		//Model
//		return admin.addPlaneDetails(planeDetails);
//	}
	
	@ModelAttribute("adminModel")
	public AdminModel adminModelObject(){
		AdminModel adminModel = new AdminModel();
		return adminModel;
	}
	
//	@ModelAttribute("planeDetails")
//	public PlaneDetails planedetailsObject(){
//		PlaneDetails planeDetails = new PlaneDetails();
//		return planeDetails;
//	}
	
	@ModelAttribute("adminReg")
	public AdminRegistration fillRegistrationForm(){
		AdminRegistration adminReg = new AdminRegistration();
		return adminReg;
	}
}
