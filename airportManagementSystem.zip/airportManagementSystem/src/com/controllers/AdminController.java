package com.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.loginaccess.AdminHandler;
import com.pojo.PlaneDetails;

@Controller
public class AdminController {

	AdminHandler admin = new AdminHandler();
	
	@RequestMapping("addDetails")
	public String enterDetails(){
		//System.out.println(planeDetails.getOwnerContactNumber());
		//ModelAndView mv = new ModelAndView();
		//Model
		return "viewPlaneDetails";
	}
	
	@RequestMapping("addPlanes")
	public String addPlaneDetails(@ModelAttribute("planeDetails") PlaneDetails planeDetails){
		System.out.println(planeDetails.getOwnerContactNumber());
		//ModelAndView mv = new ModelAndView();
		//Model
		return admin.addPlaneDetails(planeDetails);
	}
	
	@ModelAttribute("planeDetails")
	public PlaneDetails planedetailsObject(){
		PlaneDetails planeDetails = new PlaneDetails();
		return planeDetails;
	}
	
}
