package com.pojo;

public class PlaneDetails {
	private String planeId;
	private String ownerId;
	private String ownerFirstName;
	private String ownerLastName;
	private String ownerContactNumber;
	private String planeName;
	private String planeCapacity;
	public String getPlaneId() {
		return planeId;
	}
	public void setPlaneId(String planeId) {
		this.planeId = planeId;
	}
	public String getOwnerId() {
		return ownerId;
	}
	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}
	public String getOwnerFirstName() {
		return ownerFirstName;
	}
	public void setOwnerFirstName(String ownerFirstName) {
		this.ownerFirstName = ownerFirstName;
	}
	public String getOwnerLastName() {
		return ownerLastName;
	}
	public void setOwnerLastName(String ownerLastName) {
		this.ownerLastName = ownerLastName;
	}
	public String getOwnerContactNumber() {
		return ownerContactNumber;
	}
	public void setOwnerContactNumber(String ownerContactNumber) {
		this.ownerContactNumber = ownerContactNumber;
	}
	public String getPlaneName() {
		return planeName;
	}
	public void setPlaneName(String planeName) {
		this.planeName = planeName;
	}
	public String getPlaneCapacity() {
		return planeCapacity;
	}
	public void setPlaneCapacity(String planeCapacity) {
		this.planeCapacity = planeCapacity;
	}
	

}
