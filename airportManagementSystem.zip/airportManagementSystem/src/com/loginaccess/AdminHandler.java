package com.loginaccess;

import com.pojo.AdminRegistration;
import com.pojo.PlaneDetails;

public class AdminHandler {
    
	public boolean checkUser(String uname, String pass){
		if(uname.equals("ankit") && pass.equals("sharma"))
		    return true;
		
		return false;
	}
	
	public String addPlaneDetails(PlaneDetails planeDetails){
		if(planeDetails.getOwnerContactNumber().equals("9560305640")){
			return "viewPlaneDetails";
		}
		return "view";
	}
	
	public boolean adminRegistrationDetails(AdminRegistration adminReg){
		System.out.println(adminReg.getFirstName()+"  admin first name");
		if(adminReg.getFirstName().equals("ankit"))
			return true;
		return false;
	}

}
